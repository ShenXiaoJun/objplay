/// Class used to multiply stuff.
public class Multiplier {
  public init() {}

  public func multiply(a first: Int, b second: Int) -> Int {
      return first * second
  }
}
